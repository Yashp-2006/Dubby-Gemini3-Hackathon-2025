import React, { useCallback, useState } from 'react';
import { UploadCloud, FileVideo, CheckCircle2, X } from 'lucide-react';
import { AppState } from '../types';

interface DropZoneProps {
  appState: AppState;
  onFileSelected: (file: File) => void;
  onRemoveMedia: () => void;
  selectedFileName: string | null;
  setIsLookingDown: (isLooking: boolean) => void;
}

const DropZone: React.FC<DropZoneProps> = ({ 
  appState, 
  onFileSelected, 
  onRemoveMedia,
  selectedFileName, 
  setIsLookingDown
}) => {
  const [isDragging, setIsDragging] = useState(false);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
    setIsLookingDown(true);
  }, [setIsLookingDown]);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    setIsLookingDown(false);
  }, [setIsLookingDown]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    setIsLookingDown(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      if (file.type.startsWith('video/')) {
        onFileSelected(file);
      } else {
        alert('Please drop a valid video file!');
      }
    }
  }, [onFileSelected, setIsLookingDown]);

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onFileSelected(e.target.files[0]);
    }
  }, [onFileSelected]);

  const isDisabled = appState === AppState.PROCESSING_WATCHING || appState === AppState.PROCESSING_REWRITING || appState === AppState.ANIMATING_INTO_MOUTH;
  const hasMedia = !!selectedFileName;

  return (
    <div
      className={`relative w-full max-w-3xl mx-auto border-4 border-dashed rounded-[2rem] md:rounded-[2.5rem] transition-all duration-300 ease-in-out flex flex-col items-center justify-center p-6 md:p-8 text-center group overflow-hidden z-10 backdrop-blur-md
        ${isDragging 
            ? 'border-orange-500 bg-orange-50/90 shadow-2xl shadow-orange-500/20 scale-[1.02]' 
            : 'border-gray-200/80 bg-white/60 hover:border-orange-300 hover:bg-white/80 hover:shadow-xl hover:shadow-orange-500/10'
        }
        ${hasMedia ? 'border-solid border-transparent bg-white shadow-xl h-auto py-6 md:py-8' : 'h-48 md:h-64'}
        ${isDisabled ? 'opacity-50 cursor-not-allowed pointer-events-none' : ''}
      `}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      onMouseEnter={() => !hasMedia && setIsLookingDown(true)}
      onMouseLeave={() => setIsLookingDown(false)}
    >
      {!hasMedia && (
          <div 
            className="absolute inset-0 z-0 cursor-pointer"
            onClick={() => !isDisabled && document.getElementById('file-upload')?.click()}
          />
      )}
      
      <input
        id="file-upload"
        type="file"
        accept="video/*"
        className="hidden"
        onChange={handleFileInput}
        disabled={isDisabled}
      />

      {/* Decor */}
      <div className={`absolute inset-0 pointer-events-none transition-opacity duration-500 ${isDragging ? 'opacity-100' : 'opacity-0'}`}>
         <div className="absolute top-6 left-6 w-3 h-3 rounded-full bg-orange-300 animate-bounce"></div>
         <div className="absolute bottom-6 right-6 w-5 h-5 rounded-full bg-sky-300 animate-bounce" style={{ animationDelay: '0.1s' }}></div>
      </div>

      {hasMedia ? (
        <div className="flex flex-col items-center animate-in fade-in zoom-in duration-300 relative z-10 w-full px-4">
          <button 
            onClick={(e) => {
                e.stopPropagation();
                onRemoveMedia();
            }}
            className="absolute -top-3 -right-2 md:-top-4 md:-right-4 bg-red-100 hover:bg-red-200 text-red-500 p-1.5 rounded-full transition-colors z-20 group/remove"
            title="Remove video"
          >
            <X className="w-4 h-4 group-hover/remove:rotate-90 transition-transform" />
          </button>

          <div className="bg-green-100 p-3 rounded-full mb-3 shadow-sm">
             <CheckCircle2 className="w-8 h-8 md:w-10 md:h-10 text-green-600" />
          </div>
          <h3 className="text-lg md:text-xl font-bold text-gray-800 break-all max-w-lg line-clamp-1 leading-tight">
            {selectedFileName}
          </h3>
          <p className="text-sm text-gray-400 mt-1 font-medium">Ready to be dubbed!</p>
          <button 
            onClick={(e) => {
                e.stopPropagation();
                if (selectedFileName) document.getElementById('file-upload')?.click();
            }}
            className="text-xs text-orange-500 mt-2 font-bold uppercase tracking-wide hover:underline z-20 relative cursor-pointer"
          >
            Choose a different video
          </button>
        </div>
      ) : (
        <div className="relative z-10 flex flex-col items-center w-full pointer-events-none">
          <div className="mb-2 md:mb-4">
            <div className={`mx-auto w-16 h-16 md:w-20 md:h-20 flex items-center justify-center rounded-[1.5rem] mb-3 transition-all duration-300 shadow-sm ${isDragging ? 'bg-orange-200 rotate-12 scale-110' : 'bg-sky-100 group-hover:bg-orange-100 group-hover:scale-105 group-hover:-rotate-3'}`}>
                {isDragging ? (
                <UploadCloud className="w-8 h-8 md:w-10 md:h-10 text-orange-600" />
                ) : (
                <FileVideo className="w-8 h-8 md:w-10 md:h-10 text-sky-500 group-hover:text-orange-500 transition-colors" />
                )}
            </div>
            <h3 className="text-xl md:text-2xl font-black text-gray-800 tracking-tight">
                {isDragging ? 'Drop it here!' : 'Upload Video'}
            </h3>
            <p className="text-sm md:text-base text-gray-400 mt-1 font-medium">
                Drag & Drop or <span className="text-orange-500 font-bold underline decoration-2 decoration-orange-200">Browse</span>
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default DropZone;