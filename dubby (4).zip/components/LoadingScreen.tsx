import React from 'react';

interface LoadingScreenProps {
  text: string;
  subText?: string;
  variant?: 'initial' | 'processing';
}

const LoadingScreen: React.FC<LoadingScreenProps> = ({ text, subText, variant = 'initial' }) => {
  const isProcessing = variant === 'processing';

  // Colors based on variant
  // Use dark background for processing (Cinema mode) to let Orange Dubby pop
  const bgColor = isProcessing ? 'bg-gray-900' : 'bg-sky-50';
  const textColor = isProcessing ? 'text-white' : 'text-gray-800';
  const subTextColor = isProcessing ? 'text-gray-400' : 'text-gray-400';
  
  // Dubby Colors - Always keep Dubby Orange (removed the white ghost variant)
  const bodyGradient = 'bg-gradient-to-br from-orange-300 via-orange-400 to-orange-500 shadow-[inset_-10px_-10px_20px_rgba(194,65,12,0.2),0_20px_60px_-15px_rgba(249,115,22,0.6)]';
    
  const borderColor = 'border-orange-600/10';
  
  const legColor = 'bg-orange-500';
  
  // Eyes
  const eyeBg = 'bg-white';
  const eyeBorder = 'border-gray-900/5';
  const pupilBg = 'bg-gray-900';
  
  // Mouth
  const mouthBg = 'bg-gray-900';
  const tongueBg = 'bg-red-500';

  // Branding
  const brandingColor = 'text-orange-600/20';

  // Bubbles
  const blueBubbleBg = 'bg-sky-500';
  const orangeBubbleBg = 'bg-orange-500 text-white';
  const bubbleBorder = 'border-white';

  return (
    <div className={`fixed inset-0 z-50 flex flex-col items-center justify-center ${bgColor} transition-colors duration-500 overflow-hidden`}>
      <style>{`
        @keyframes jump-bounce {
          0%, 100% { transform: translateY(0) scale(1, 1); }
          15% { transform: translateY(0) scale(1.15, 0.85); } /* Squash pre-jump */
          40% { transform: translateY(-100px) scale(0.9, 1.1); } /* Peak of jump, stretch */
          60% { transform: translateY(-40px) scale(0.95, 1.05); } /* Coming down */
          75% { transform: translateY(0) scale(1.1, 0.9); } /* Land squash */
          85% { transform: translateY(0) scale(0.98, 1.02); } /* Rebound stretch */
        }
        @keyframes shadow-scale {
          0%, 100% { transform: scale(1); opacity: 0.3; }
          40% { transform: scale(0.5); opacity: 0.1; }
        }
        @keyframes look-around-simple {
           0%, 100% { transform: translate(0,0); }
           20% { transform: translate(4px, -2px); }
           50% { transform: translate(-4px, -2px); }
        }
        @keyframes float-bubble {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-5px); }
        }
      `}</style>

      {/* Container for the Mascot */}
      <div className="relative mb-12 md:mb-16 scale-[0.6] md:scale-75 origin-bottom">
        
        {/* Dubby Wrapper with Jump Animation */}
        <div style={{ animation: 'jump-bounce 1.2s infinite cubic-bezier(0.28, 0.84, 0.42, 1)', transformOrigin: 'bottom center' }} className="relative z-10">
             
             {/* Bubbles - Moving with the jump but having own float */}
             <div className="absolute top-0 w-full h-full z-20 pointer-events-none">
                 {/* Right (Blue) */}
                 <div className={`absolute -right-20 top-0 ${blueBubbleBg} text-white w-20 h-16 flex flex-col items-center justify-center rounded-[2rem] rounded-bl-none shadow-lg border-2 ${bubbleBorder}`} style={{ animation: 'float-bubble 3s ease-in-out infinite' }}>
                    <div className="flex gap-1 items-baseline">
                        <span className="font-bold text-xl">あ</span>
                        <span className="font-bold text-sm opacity-90">é</span>
                    </div>
                    <div className={`w-2 h-2 ${blueBubbleBg} absolute -bottom-1 -left-1 rotate-45`}></div>
                 </div>
                 
                 {/* Left (Orange/White) */}
                 <div className={`absolute -left-16 top-10 ${orangeBubbleBg} w-14 h-14 flex items-center justify-center rounded-2xl rounded-tr-none shadow-lg border-2 ${bubbleBorder}`} style={{ animation: 'float-bubble 3.5s ease-in-out infinite 0.5s' }}>
                    <span className="font-bold text-2xl">A</span>
                    <div className={`w-2 h-2 bg-orange-500 absolute -top-0.5 -right-1 rotate-45`}></div>
                 </div>
             </div>

             {/* Legs */}
             <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-5 z-0">
                 <div className={`w-5 h-14 ${legColor} rounded-full -rotate-6 relative top-1 shadow-sm`}>
                    <div className="absolute bottom-0 -left-1 w-7 h-4 bg-orange-500 rounded-full border-b-4 border-orange-600"></div>
                 </div>
                 <div className={`w-5 h-14 ${legColor} rounded-full rotate-6 relative top-1 shadow-sm`}>
                    <div className="absolute bottom-0 -left-1 w-7 h-4 bg-orange-500 rounded-full border-b-4 border-orange-600"></div>
                 </div>
             </div>

             {/* Main Body */}
             <div className={`w-48 h-64 ${bodyGradient} rounded-[45%_45%_40%_40%] border-[5px] ${borderColor} flex flex-col items-center pt-16 relative overflow-hidden`}>
                
                {/* Glossy Highlight */}
                <div className={`absolute top-4 left-6 w-16 h-24 bg-gradient-to-br from-white/40 to-transparent rounded-full rotate-[-15deg] blur-[2px]`}></div>
                <div className={`absolute top-6 left-10 w-4 h-4 bg-white/60 rounded-full blur-[1px]`}></div>

                {/* Face Container */}
                <div className="flex flex-col items-center gap-3 z-20 relative top-2">
                    
                    {/* Eyes */}
                    <div className="flex gap-6">
                        <div className={`w-10 h-12 ${eyeBg} rounded-[50%] relative overflow-hidden border-[3px] ${eyeBorder} shadow-inner`}>
                            <div className={`w-5 h-6 ${pupilBg} rounded-full absolute top-2 left-2`} style={{ animation: 'look-around-simple 2s infinite' }}>
                                <div className={`absolute top-1.5 right-1 w-2 h-2 bg-white rounded-full opacity-80`}></div>
                            </div>
                        </div>
                        <div className={`w-10 h-12 ${eyeBg} rounded-[50%] relative overflow-hidden border-[3px] ${eyeBorder} shadow-inner`}>
                             <div className={`w-5 h-6 ${pupilBg} rounded-full absolute top-2 left-2`} style={{ animation: 'look-around-simple 2s infinite' }}>
                                <div className={`absolute top-1.5 right-1 w-2 h-2 bg-white rounded-full opacity-80`}></div>
                            </div>
                        </div>
                    </div>

                    {/* Mouth */}
                    <div className={`w-16 h-8 ${mouthBg} rounded-b-[3rem] relative overflow-hidden mt-1 border-t-2 border-transparent`}>
                         <div className={`absolute bottom-[-10px] left-1/2 -translate-x-1/2 w-10 h-10 ${tongueBg} rounded-full shadow-[inset_0_2px_4px_rgba(0,0,0,0.2)]`}></div>
                    </div>
                </div>

                {/* Chest Branding "D" */}
                <div className={`absolute bottom-4 font-black text-8xl ${brandingColor} mix-blend-multiply select-none`}>D</div>
            </div>
        </div>

        {/* Shadow */}
        <div 
            className="absolute -bottom-8 left-1/2 -translate-x-1/2 w-36 h-6 bg-black/10 rounded-[100%] blur-md -z-10"
            style={{ animation: 'shadow-scale 1.2s infinite cubic-bezier(0.28, 0.84, 0.42, 1)' }}
        ></div>
      </div>

      <h2 className={`text-3xl md:text-5xl font-black mb-4 ${textColor} animate-pulse text-center px-4 tracking-tight`}>
        {text}
      </h2>
      {subText && (
        <p className={`text-lg md:text-xl font-medium ${subTextColor} text-center px-4 max-w-lg leading-relaxed`}>
            {subText}
        </p>
      )}

    </div>
  );
};

export default LoadingScreen;