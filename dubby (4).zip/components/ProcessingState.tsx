import React from 'react';
import { AppState } from '../types';
import { Eye, Pencil } from 'lucide-react';

interface ProcessingStateProps {
  appState: AppState;
}

const ProcessingState: React.FC<ProcessingStateProps> = ({ appState }) => {
  if (appState !== AppState.PROCESSING_WATCHING && appState !== AppState.PROCESSING_REWRITING) {
    return null;
  }

  const isWatching = appState === AppState.PROCESSING_WATCHING;

  return (
    <div className="w-full max-w-2xl mx-auto mt-8 bg-white rounded-[2rem] p-8 shadow-sm border border-gray-100 text-center animate-in fade-in zoom-in duration-500">
      <div className="flex justify-center mb-6 relative">
         {/* Animated circle bg */}
         <div className="absolute inset-0 flex items-center justify-center">
             <div className="w-24 h-24 bg-orange-100 rounded-full animate-ping opacity-75"></div>
         </div>
         
         <div className="relative z-10 bg-white p-4 rounded-full border-4 border-orange-100 shadow-sm">
            {isWatching ? (
                <Eye className="w-12 h-12 text-orange-500 animate-pulse" />
            ) : (
                <Pencil className="w-12 h-12 text-orange-500 animate-bounce" />
            )}
         </div>
      </div>
      
      <h3 className="text-2xl font-bold text-gray-800 mb-2">
        {isWatching ? 'Dubby is watching the video...' : 'Dubby is rewriting the script...'}
      </h3>
      <p className="text-gray-500">
        {isWatching 
          ? 'Analyzing facial movements and speech patterns.' 
          : 'Optimizing words for perfect lip synchronization.'}
      </p>
      
      <div className="w-full bg-gray-100 rounded-full h-2.5 mt-8 overflow-hidden">
        <div 
            className="bg-orange-500 h-2.5 rounded-full transition-all duration-[2000ms] ease-linear" 
            style={{ width: isWatching ? '45%' : '90%' }}
        ></div>
      </div>
    </div>
  );
};

export default ProcessingState;