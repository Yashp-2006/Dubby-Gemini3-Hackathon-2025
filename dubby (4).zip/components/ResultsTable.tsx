import React, { useRef, useState, useEffect } from 'react';
import { DubbingResult, Language, GeminiVoice } from '../types';
import { parseTimestamp, decodeBase64, decodeAudioData } from '../utils';
import { BrainCircuit, Play, Pause, Volume2, VolumeX, Sparkles, Upload, Loader2, PlayCircle, Clock, Download, ChevronRight, Zap, Hourglass } from 'lucide-react';
import ReactPlayer from 'react-player';
import { GoogleGenAI, Modality } from "@google/genai";

interface ResultsTableProps {
  results: DubbingResult[];
  videoUrl: string | null;
  targetLanguage: Language;
  onVideoUpdate: (file: File) => void;
  voice: GeminiVoice;
}

const ResultsTable: React.FC<ResultsTableProps> = ({ results, videoUrl, targetLanguage, onVideoUpdate, voice }) => {
  const playerRef = useRef<ReactPlayer>(null);
  
  // User intended state (Play/Pause button)
  const [isPlaying, setIsPlaying] = useState(false);
  // System override state (Pausing video to let audio finish)
  const [isWaitingForAudio, setIsWaitingForAudio] = useState(false);
  
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [activeSegmentId, setActiveSegmentId] = useState<string | null>(null);
  const [isDubbingEnabled, setIsDubbingEnabled] = useState(true);
  const segmentRefs = useRef<{[key: string]: HTMLDivElement | null}>({});
  
  // Audio Playback State
  const audioContextRef = useRef<AudioContext | null>(null);
  const activeSourceRef = useRef<AudioBufferSourceNode | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  const [audioCache, setAudioCache] = useState<Record<string, AudioBuffer>>({});
  const [loadingAudioFor, setLoadingAudioFor] = useState<Record<string, boolean>>({});
  
  // Track what we are currently playing to avoid restarting the same audio
  const playingSegmentIdRef = useRef<string | null>(null);
  const audioStartTimeRef = useRef<number>(0); // When the current audio source started (context time)

  // Sync State
  const [playbackRate, setPlaybackRate] = useState(1.0);
  const [isFallbackActive, setIsFallbackActive] = useState(false);

  // Initialize Audio Context on mount
  useEffect(() => {
    const Ctx = window.AudioContext || (window as any).webkitAudioContext;
    audioContextRef.current = new Ctx();
    
    // Create Gain Node for Volume Control
    gainNodeRef.current = audioContextRef.current.createGain();
    gainNodeRef.current.gain.value = 0.9; 
    gainNodeRef.current.connect(audioContextRef.current.destination);

    return () => {
        if (audioContextRef.current) {
            audioContextRef.current.close();
        }
        window.speechSynthesis.cancel();
    };
  }, []);

  // Auto-scroll to active segment
  useEffect(() => {
    if (activeSegmentId && segmentRefs.current[activeSegmentId]) {
      segmentRefs.current[activeSegmentId]?.scrollIntoView({
        behavior: 'smooth',
        block: 'center',
      });
    }
  }, [activeSegmentId]);

  // Pre-fetch Audio for segments
  useEffect(() => {
    setAudioCache({});
    setLoadingAudioFor({});
    playingSegmentIdRef.current = null;
    
    // Process sequentially/parallel
    results.forEach(result => {
        generateAudioForSegment(result.id, result.optimizedText);
    });
  }, [results, voice]);

  const generateAudioForSegment = async (id: string, text: string) => {
    if (loadingAudioFor[id]) return;

    setLoadingAudioFor(prev => ({ ...prev, [id]: true }));

    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-tts",
            contents: [{ parts: [{ text: text }] }],
            config: {
                responseModalities: [Modality.AUDIO],
                systemInstruction: "You are a friendly, human voice actor. Speak naturally with a conversational, warm tone. Do not sound robotic. Maintain a moderate volume.",
                speechConfig: {
                    voiceConfig: {
                        prebuiltVoiceConfig: { voiceName: voice },
                    },
                },
            },
        });

        const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        if (base64Audio && audioContextRef.current) {
            const bytes = decodeBase64(base64Audio);
            const audioBuffer = await decodeAudioData(bytes, audioContextRef.current, 24000);
            setAudioCache(prev => ({ ...prev, [id]: audioBuffer }));
        }
    } catch (error) {
        console.warn("Gemini Audio Generation Failed for segment " + id, error);
    } finally {
        setLoadingAudioFor(prev => ({ ...prev, [id]: false }));
    }
  };

  const stopAllAudio = () => {
      // Stop Web Audio
      if (activeSourceRef.current) {
          try { activeSourceRef.current.stop(); } catch (e) { /* ignore */ }
          activeSourceRef.current = null;
      }
      // Stop Browser TTS
      window.speechSynthesis.cancel();
      setIsFallbackActive(false);
      playingSegmentIdRef.current = null;
      
      // Reset waiting state
      setIsWaitingForAudio(false);
  };

  const playFallbackAudio = (text: string) => {
      setIsFallbackActive(true);
      const utterance = new SpeechSynthesisUtterance(text);
      const voices = window.speechSynthesis.getVoices();
      const preferredVoice = voices.find(v => 
        (v.name.includes('Google US English') || v.name.includes('Male')) && v.lang.startsWith('en')
      );
      if (preferredVoice) utterance.voice = preferredVoice;
      utterance.volume = 0.9; 
      
      utterance.onend = () => {
          setIsWaitingForAudio(false);
      };
      
      window.speechSynthesis.speak(utterance);
  };

  const playSegmentAudio = async (id: string, text: string, offset: number = 0) => {
    // 1. Always stop previous audio to avoid overlap
    stopAllAudio();
    playingSegmentIdRef.current = id;

    // 2. Resume Context if needed
    if (audioContextRef.current?.state === 'suspended') {
        try { await audioContextRef.current.resume(); } catch (e) { console.error(e); }
    }

    // 3. Try Cache
    const buffer = audioCache[id];
    if (buffer && audioContextRef.current && gainNodeRef.current) {
        try {
            const source = audioContextRef.current.createBufferSource();
            source.buffer = buffer;
            source.connect(gainNodeRef.current);
            
            // Store the "virtual" start time (context time when offset 0 would have started)
            // This is crucial for calculating "remaining time" later
            audioStartTimeRef.current = audioContextRef.current.currentTime - offset;
            
            // Only play if offset is within the audio duration
            if (offset < buffer.duration) {
                source.start(0, offset); 
                activeSourceRef.current = source;
                
                source.onended = () => {
                   if (activeSourceRef.current === source) {
                       activeSourceRef.current = null;
                       // AUDIO FINISHED NATURALLY -> RESUME VIDEO
                       setIsWaitingForAudio(false); 
                   }
                };
            }
        } catch (e) {
            console.error("Audio playback error", e);
        }
    } else {
        // Fallback to TTS (only if starting near the beginning)
        if (offset < 0.5) {
             playFallbackAudio(text);
        }
    }
  };

  const togglePlay = () => {
    const nextPlayingState = !isPlaying;
    setIsPlaying(nextPlayingState);
    
    if (!nextPlayingState) {
        stopAllAudio();
        setPlaybackRate(1.0);
    } else {
        if (audioContextRef.current?.state === 'suspended') {
            audioContextRef.current.resume();
        }
    }
  };

  const handleProgress = (state: { playedSeconds: number }) => {
    // If waiting for audio, do not update time or logic (video is paused)
    if (isWaitingForAudio) return;

    const time = state.playedSeconds;
    setCurrentTime(time);
    
    // Find active segment based on current time
    const active = results.find(r => {
        const start = parseTimestamp(r.startTime);
        const end = parseTimestamp(r.endTime);
        return time >= start && time <= end;
    });

    if (active) {
        setActiveSegmentId(active.id);

        if (isDubbingEnabled && isPlaying) {
            
            // 1. START AUDIO if not playing this segment
            if (playingSegmentIdRef.current !== active.id) {
                const start = parseTimestamp(active.startTime);
                const offset = Math.max(0, time - start);
                
                playSegmentAudio(active.id, active.optimizedText, offset);
                
                // --- Semantic Rate Control (Slow video to match audio) ---
                const buffer = audioCache[active.id];
                if (buffer) {
                    const audioDur = buffer.duration;
                    const videoSegDur = parseTimestamp(active.endTime) - start;
                    
                    if (audioDur > 0 && videoSegDur > 0) {
                        // If audio is longer, rate < 1 (slow down)
                        let rate = videoSegDur / audioDur;
                        // Allow slowing down significantly to match audio
                        rate = Math.max(0.2, Math.min(1.5, rate));
                        setPlaybackRate(rate);
                    }
                } else {
                    setPlaybackRate(1.0);
                }
            }
            
            // 2. CHECK SYNC / WAIT FOR AUDIO
            // If video is about to end, but audio is still going, PAUSE video.
            if (playingSegmentIdRef.current === active.id && activeSourceRef.current && audioContextRef.current) {
                const videoEnd = parseTimestamp(active.endTime);
                const videoRemaining = videoEnd - time;
                
                const buffer = audioCache[active.id];
                if (buffer) {
                     const audioElapsed = audioContextRef.current.currentTime - audioStartTimeRef.current;
                     const audioRemaining = buffer.duration - audioElapsed;
                     
                     // If video is within 0.2s of ending, but audio needs more than 0.25s
                     if (videoRemaining < 0.2 && audioRemaining > 0.25) {
                         if (!isWaitingForAudio) {
                             setIsWaitingForAudio(true); // Video Pauses here via playing prop
                         }
                     }
                }
            }
        }
    } else {
        // GAP detected
        if (activeSegmentId !== null) {
            setActiveSegmentId(null);
            // Reset for gap
            setIsWaitingForAudio(false);
            setPlaybackRate(1.0);
            // We allow audio to bleed into the gap naturally
        }
    }
  };

  const formatTime = (time: number) => {
    const min = Math.floor(time / 60);
    const sec = Math.floor(time % 60);
    return `${min}:${sec < 10 ? '0' : ''}${sec}`;
  };

  // Called when user drags the slider
  const seek = (e: React.ChangeEvent<HTMLInputElement>) => {
      const time = parseFloat(e.target.value);
      if (playerRef.current) {
          playerRef.current.seekTo(time);
          setCurrentTime(time);
          stopAllAudio(); 
          setPlaybackRate(1.0);
          setIsWaitingForAudio(false);
      }
  };

  const handleSeekToSegment = (startTimeStr: string) => {
      if (playerRef.current) {
          const time = parseTimestamp(startTimeStr);
          playerRef.current.seekTo(time);
          setCurrentTime(time);
          setIsPlaying(true); // User Intent: Play
          setIsWaitingForAudio(false);
          
          stopAllAudio();
          setPlaybackRate(1.0);
      }
  };

  // Determine actual playing state passed to ReactPlayer
  // We play if user wants to play AND we are not waiting for audio to catch up
  const effectivePlaying = isPlaying && !isWaitingForAudio;

  return (
    <div className="w-full mt-0 animate-in slide-in-from-bottom-20 fade-in duration-1000">
      
      <div className="flex flex-col lg:flex-row gap-8 lg:gap-12 items-start">
        
        {/* LEFT COLUMN: Video Player (Sticky on Desktop) */}
        <div className="w-full lg:w-[40%] lg:sticky lg:top-4 z-30">
          <div className="rounded-[1.5rem] md:rounded-[2rem] overflow-hidden shadow-2xl shadow-orange-500/20 border-4 border-white bg-black aspect-video relative group transition-transform duration-500 hover:scale-[1.005]">
            {videoUrl ? (
                <ReactPlayer 
                    ref={playerRef}
                    url={videoUrl}
                    playing={effectivePlaying}
                    onProgress={handleProgress}
                    onDuration={setDuration}
                    onEnded={() => { setIsPlaying(false); stopAllAudio(); setPlaybackRate(1.0); }}
                    width="100%"
                    height="100%"
                    muted={isDubbingEnabled} // Enforce mute when dubbing is on
                    volume={1} // Original video volume
                    playsinline
                    progressInterval={50} // High precision
                    playbackRate={playbackRate}
                />
            ) : (
                <div className="absolute inset-0 bg-gray-900 flex flex-col items-center justify-center p-4 text-center">
                    <span className="text-white/20 font-black text-4xl mb-4">NO VIDEO</span>
                    <label className="cursor-pointer bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-full font-bold transition-all flex items-center gap-2 border border-white/10">
                        <Upload className="w-4 h-4 text-orange-400" />
                        <span>Upload Video</span>
                        <input 
                            type="file" 
                            accept="video/*" 
                            className="hidden" 
                            onChange={(e) => e.target.files?.[0] && onVideoUpdate(e.target.files[0])}
                        />
                    </label>
                </div>
            )}
            
            {/* Speed / Sync Indicator Overlay */}
            {playbackRate !== 1.0 && effectivePlaying && (
                 <div className="absolute top-4 right-4 bg-black/60 backdrop-blur text-white text-xs font-mono px-2 py-1 rounded border border-white/20 flex items-center gap-2 animate-pulse">
                    <Zap className="w-3 h-3 text-orange-400" />
                    <span>Sync: {playbackRate.toFixed(2)}x</span>
                 </div>
            )}

            {/* Wait Indicator */}
            {isWaitingForAudio && isPlaying && (
                 <div className="absolute top-4 right-4 bg-orange-600/90 backdrop-blur text-white text-xs font-mono px-3 py-1.5 rounded-full border border-orange-400/50 flex items-center gap-2 shadow-lg animate-bounce">
                    <Hourglass className="w-3 h-3 text-white" />
                    <span>Syncing...</span>
                 </div>
            )}
            
            {/* Fallback Audio Warning */}
            {isFallbackActive && isPlaying && (
                <div className="absolute top-4 left-4 bg-red-900/80 backdrop-blur text-white text-xs font-mono px-2 py-1 rounded border border-red-500/50 flex items-center gap-2">
                    <span>⚠️ Low Quality Audio Fallback</span>
                </div>
            )}

            {/* Controls Overlay */}
            <div className={`absolute bottom-0 left-0 right-0 p-3 md:p-6 bg-gradient-to-t from-black/90 via-black/50 to-transparent transition-opacity duration-300 ${isPlaying ? 'opacity-0 group-hover:opacity-100' : 'opacity-100'}`}>
                {/* Progress */}
                <div className="relative w-full h-1.5 bg-white/20 rounded-full mb-3 cursor-pointer group/progress">
                    <input 
                        type="range" 
                        min="0" 
                        max={duration || 100} 
                        value={currentTime} 
                        onChange={seek}
                        step="0.1"
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-20"
                    />
                    <div 
                        className="h-full bg-orange-500 rounded-full relative z-10 pointer-events-none" 
                        style={{ width: `${(currentTime / (duration || 1)) * 100}%` }}
                    >
                        <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 bg-white rounded-full scale-0 group-hover/progress:scale-100 transition-transform shadow"></div>
                    </div>
                </div>

                <div className="flex items-center justify-between text-white">
                    <div className="flex items-center gap-3">
                        <button onClick={togglePlay} className="hover:text-orange-400 transition-colors">
                            {isPlaying ? <Pause className="w-6 h-6 fill-current" /> : <Play className="w-6 h-6 fill-current" />}
                        </button>
                        
                        <button 
                            onClick={() => setIsDubbingEnabled(!isDubbingEnabled)}
                            className={`flex items-center gap-1.5 text-[10px] md:text-xs font-bold px-2 py-1 rounded-full transition-all border ${isDubbingEnabled ? 'bg-orange-500 border-orange-500 text-white' : 'bg-transparent border-white/30 text-white/70 hover:bg-white/10'}`}
                        >
                            {isDubbingEnabled ? <Volume2 className="w-3 h-3" /> : <VolumeX className="w-3 h-3" />}
                            <span className="whitespace-nowrap">{isDubbingEnabled ? 'DUBBED' : 'ORIGINAL'}</span>
                        </button>

                        <span className="text-xs font-medium font-mono text-gray-300">
                            {formatTime(currentTime)} / {formatTime(duration)}
                        </span>
                    </div>

                    <label className="cursor-pointer text-white/50 hover:text-white transition-colors" title="Change Video">
                        <Upload className="w-4 h-4" />
                        <input 
                            type="file" 
                            accept="video/*" 
                            className="hidden" 
                            onChange={(e) => e.target.files?.[0] && onVideoUpdate(e.target.files[0])}
                        />
                    </label>
                </div>
            </div>
            
            {/* Big Center Play Button */}
            {!isPlaying && videoUrl && (
                <div 
                    onClick={togglePlay}
                    className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-16 h-16 bg-orange-500/90 rounded-full flex items-center justify-center cursor-pointer hover:scale-110 transition-transform shadow-lg shadow-orange-500/50 backdrop-blur-sm z-10"
                >
                    <Play className="w-8 h-8 text-white fill-white ml-1" />
                </div>
            )}
          </div>

          {/* Desktop Meta Info */}
          <div className="hidden lg:block mt-6 bg-white/60 backdrop-blur-sm rounded-2xl p-6 border border-white/50 shadow-sm">
             <div className="flex items-center justify-between">
                 <div>
                    <h3 className="text-lg font-bold text-gray-800 flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-green-500 animate-pulse"></span>
                        Ready to Export
                    </h3>
                    <p className="text-sm text-gray-500 mt-1">
                        Voice: <span className="font-semibold text-orange-600">{voice}</span> • Target: <span className="font-semibold text-orange-600">{targetLanguage}</span>
                    </p>
                 </div>
                 <button className="flex items-center gap-2 bg-gray-900 text-white text-sm font-bold px-6 py-3 rounded-xl hover:bg-gray-800 transition-colors shadow-lg shadow-gray-900/10">
                    <Download className="w-4 h-4" />
                    <span>Download JSON</span>
                 </button>
             </div>
          </div>
        </div>

        {/* RIGHT COLUMN: Transcript / Segments List */}
        <div className="w-full lg:w-[60%] flex flex-col gap-6">
            
            <div className="flex items-center justify-between sticky top-0 lg:static bg-sky-50 lg:bg-transparent py-4 z-20 backdrop-blur-sm lg:backdrop-blur-none border-b border-gray-200/50 lg:border-none">
                 <div className="flex items-center gap-4">
                    <div className="bg-orange-100 p-3 rounded-2xl shadow-sm">
                        <BrainCircuit className="w-6 h-6 text-orange-600" />
                    </div>
                    <div>
                        <h2 className="text-2xl font-black text-gray-800 leading-none">Script & Sync</h2>
                        <p className="text-sm text-gray-400 font-medium mt-1">Master Audio Clock</p>
                    </div>
                 </div>
                 <span className="text-sm font-mono bg-white border border-gray-200 text-gray-500 px-4 py-2 rounded-full shadow-sm">
                    {results.length} Segments
                 </span>
            </div>

            <div className="flex flex-col gap-4 pb-0">
                {results.map((row) => {
                    const isActive = activeSegmentId === row.id;
                    const hasAudio = !!audioCache[row.id];
                    const isLoading = loadingAudioFor[row.id];

                    return (
                        <div 
                            key={row.id}
                            ref={el => { segmentRefs.current[row.id] = el }}
                            onClick={() => handleSeekToSegment(row.startTime)}
                            className={`relative p-6 rounded-3xl border transition-all duration-300 cursor-pointer group select-none
                                ${isActive 
                                    ? 'bg-orange-50 border-orange-300 shadow-xl shadow-orange-500/10 scale-[1.01] z-10 ring-1 ring-orange-200' 
                                    : 'bg-white/60 border-transparent hover:border-orange-200 hover:bg-white shadow-sm'
                                }
                            `}
                        >
                            {/* Time & Audio Header */}
                            <div className="flex justify-between items-center mb-4">
                                <span className={`flex items-center gap-2 font-mono text-xs font-bold px-2.5 py-1.5 rounded-lg transition-colors ${isActive ? 'bg-orange-500 text-white' : 'bg-gray-100 text-gray-500'}`}>
                                    <Clock className="w-3.5 h-3.5" />
                                    {row.startTime} - {row.endTime}
                                </span>
                                
                                <button 
                                    onClick={(e) => {
                                        e.stopPropagation();
                                        playSegmentAudio(row.id, row.optimizedText, 0);
                                    }}
                                    className={`p-2 rounded-full transition-all ${isActive ? 'bg-orange-200 text-orange-700 animate-pulse' : 'bg-gray-100 text-gray-300 hover:bg-orange-100 hover:text-orange-500'}`}
                                >
                                    {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <PlayCircle className="w-5 h-5" />}
                                </button>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-10 relative">
                                {/* Decor Divider */}
                                <div className="hidden md:block absolute left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-gray-200 to-transparent"></div>
                                <div className="md:hidden flex justify-center py-2">
                                    <ChevronRight className="w-5 h-5 text-gray-300 rotate-90" />
                                </div>

                                {/* Original */}
                                <div className="relative">
                                    <p className="text-[11px] uppercase font-bold text-gray-400 mb-2 tracking-wider">Original</p>
                                    <p className={`text-base leading-relaxed font-medium transition-colors ${isActive ? 'text-gray-500' : 'text-gray-600'}`}>{row.originalText}</p>
                                </div>
                                
                                {/* Optimized */}
                                <div className="relative">
                                    <p className="text-[11px] uppercase font-bold text-orange-400 mb-2 tracking-wider flex items-center gap-1">
                                        Dubbed
                                        {isActive && <span className="w-2 h-2 rounded-full bg-orange-500 animate-pulse"></span>}
                                    </p>
                                    <p className={`text-lg md:text-xl font-bold leading-relaxed transition-colors ${isActive ? 'text-gray-900' : 'text-gray-800'}`}>
                                        {row.optimizedText}
                                    </p>
                                </div>
                            </div>
                            
                            {/* Reasoning Footer */}
                            <div className="mt-4 pt-3 border-t border-gray-100/50 flex items-start gap-2">
                                 <Sparkles className="w-4 h-4 text-orange-400 shrink-0 mt-0.5" />
                                 <p className="text-sm text-gray-400 italic leading-snug">
                                    {row.reasoning || "Optimized for timing."}
                                 </p>
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
      </div>
    </div>
  );
};

export default ResultsTable;