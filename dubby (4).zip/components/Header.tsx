import React, { useEffect, useRef } from 'react';
import { AppState } from '../types';

interface HeaderProps {
  appState?: AppState;
  isLookingDown?: boolean;
}

const Header: React.FC<HeaderProps> = ({ appState = AppState.IDLE, isLookingDown = false }) => {
  const isZooming = appState === AppState.ANIMATING_INTO_MOUTH;
  const isHidden = appState === AppState.PROCESSING_WATCHING || appState === AppState.PROCESSING_REWRITING || appState === AppState.COMPLETE;

  const leftPupilRef = useRef<HTMLDivElement>(null);
  const rightPupilRef = useRef<HTMLDivElement>(null);

  // Dynamic Eye Tracking
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
        if (isZooming || isHidden || isLookingDown) return;

        [leftPupilRef.current, rightPupilRef.current].forEach(pupil => {
            if (!pupil) return;
            const eyeContainer = pupil.parentElement;
            if (!eyeContainer) return;

            const rect = eyeContainer.getBoundingClientRect();
            const eyeCenterX = rect.left + rect.width / 2;
            const eyeCenterY = rect.top + rect.height / 2;

            const dx = e.clientX - eyeCenterX;
            const dy = e.clientY - eyeCenterY;

            const maxMoveX = 12;
            const maxMoveY = 8;
            const sensitivity = 300; 
            const distance = Math.hypot(dx, dy);
            const factor = Math.min(distance / sensitivity, 1); 
            const angle = Math.atan2(dy, dx);
            
            const moveX = Math.cos(angle) * (maxMoveX * factor);
            const moveY = Math.sin(angle) * (maxMoveY * factor);

            pupil.style.transform = `translate(${moveX}px, ${moveY}px)`;
        });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, [isZooming, isHidden, isLookingDown]);

  useEffect(() => {
    if (isLookingDown) return;
    if (leftPupilRef.current) leftPupilRef.current.style.transform = 'translate(0, 0)';
    if (rightPupilRef.current) rightPupilRef.current.style.transform = 'translate(0, 0)';
  }, [isHidden, isLookingDown]);

  return (
    <header className={`w-full pt-2 md:pt-6 flex flex-col items-center justify-center text-center relative overflow-visible transition-all duration-500 ${isHidden ? 'opacity-0 pointer-events-none absolute' : 'opacity-100'}`}>
      
      <style>{`
        @keyframes blink {
          0%, 96%, 100% { transform: scaleY(1); }
          98% { transform: scaleY(0.1); }
        }
        .looking-down-eyes {
            transform: translate(0, 10px) !important;
        }
      `}</style>

      {/* Background Sound Waves */}
      <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] md:w-[500px] h-24 flex items-center justify-center gap-1 md:gap-2 opacity-10 pointer-events-none -z-10 transition-opacity duration-300 ${isZooming ? 'opacity-0' : 'opacity-10'}`}>
         {[...Array(20)].map((_, i) => (
            <div 
                key={i} 
                className="w-1.5 md:w-2 bg-sky-400 rounded-full animate-pulse" 
                style={{ 
                    height: `${Math.random() * 100}%`, 
                    animationDelay: `${i * 0.1}s` 
                }} 
            />
         ))}
      </div>

      {/* Dubby Mascot Construction - Scaled Down */}
      <div 
        className={`relative mb-2 md:mb-4 group cursor-pointer select-none transition-all ease-in-out z-30
            ${isZooming 
                ? 'fixed top-[55%] left-1/2 -translate-x-1/2 -translate-y-1/2 scale-[40] md:scale-[60] rotate-0 duration-[1500ms]' 
                : isLookingDown 
                    ? 'translate-y-4 rotate-x-12 scale-[0.55] md:scale-[0.75] duration-500' 
                    : 'translate-y-0 rotate-0 scale-[0.55] md:scale-[0.75] duration-500'
            }
        `}
        style={{ transformOrigin: 'center 75%' }}
      >
        {/* Legs */}
        <div className={`absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-5 z-0 transition-opacity duration-300 ${isZooming ? 'opacity-0' : 'opacity-100'}`}>
             <div className="w-5 h-14 bg-orange-500 rounded-full -rotate-6 relative top-1 shadow-sm">
                 <div className="absolute bottom-0 -left-1 w-7 h-4 bg-orange-500 rounded-full border-b-4 border-orange-600"></div>
             </div>
             <div className="w-5 h-14 bg-orange-500 rounded-full rotate-6 relative top-1 shadow-sm">
                 <div className="absolute bottom-0 -left-1 w-7 h-4 bg-orange-500 rounded-full border-b-4 border-orange-600"></div>
             </div>
        </div>

        {/* Main Body */}
        <div className={`relative z-10 w-48 h-64 bg-gradient-to-br from-orange-300 via-orange-400 to-orange-500 rounded-[45%_45%_40%_40%] shadow-[inset_-10px_-10px_20px_rgba(194,65,12,0.2),0_20px_60px_-15px_rgba(249,115,22,0.6)] border-[5px] border-orange-600/10 flex flex-col items-center pt-16 transform transition-transform duration-500 ease-in-out overflow-hidden ${!isZooming && 'group-hover:scale-105 group-hover:-translate-y-2 group-hover:rotate-1'}`}>
            <div className="absolute top-4 left-6 w-16 h-24 bg-gradient-to-br from-white/40 to-transparent rounded-full rotate-[-15deg] blur-[2px]"></div>
            <div className="absolute top-6 left-10 w-4 h-4 bg-white/60 rounded-full blur-[1px]"></div>

            {/* Face */}
            <div className={`flex flex-col items-center gap-3 z-20 relative top-2 transition-transform duration-500 ${isLookingDown ? 'translate-y-4' : 'translate-y-0'}`}>
                <div className="flex gap-6">
                    <div className="w-10 h-12 bg-white rounded-[50%] relative overflow-hidden border-[3px] border-gray-900/5 shadow-inner" style={{ animation: isLookingDown ? 'none' : 'blink 4s infinite' }}>
                        <div ref={leftPupilRef} className={`w-5 h-6 bg-gray-900 rounded-full absolute top-2 left-2 transition-transform duration-75 ease-out will-change-transform ${isLookingDown ? 'looking-down-eyes duration-300' : ''}`}>
                            <div className="absolute top-1.5 right-1 w-2 h-2 bg-white rounded-full"></div>
                        </div>
                    </div>
                    <div className="w-10 h-12 bg-white rounded-[50%] relative overflow-hidden border-[3px] border-gray-900/5 shadow-inner" style={{ animation: isLookingDown ? 'none' : 'blink 4s infinite' }}>
                         <div ref={rightPupilRef} className={`w-5 h-6 bg-gray-900 rounded-full absolute top-2 left-2 transition-transform duration-75 ease-out will-change-transform ${isLookingDown ? 'looking-down-eyes duration-300' : ''}`}>
                            <div className="absolute top-1.5 right-1 w-2 h-2 bg-white rounded-full"></div>
                        </div>
                    </div>
                </div>

                <div className={`w-16 h-8 bg-gray-900 rounded-b-[3rem] relative overflow-hidden mt-1 border-t-2 border-transparent transition-all duration-500 ${isZooming ? 'scale-[1.5] translate-y-2' : ''}`}>
                     <div className="absolute bottom-[-10px] left-1/2 -translate-x-1/2 w-10 h-10 bg-red-500 rounded-full shadow-[inset_0_2px_4px_rgba(0,0,0,0.2)]"></div>
                </div>
            </div>

            <div className={`absolute bottom-4 font-black text-8xl text-orange-600/20 mix-blend-multiply select-none transition-opacity duration-300 ${isZooming ? 'opacity-0' : 'opacity-100'}`}>D</div>
        </div>

        {/* Bubbles */}
        <div className={`transition-opacity duration-300 ${isZooming ? 'opacity-0' : 'opacity-100'}`}>
            <div className="absolute -right-16 top-0 bg-sky-500 text-white w-20 h-16 flex flex-col items-center justify-center rounded-[2rem] rounded-bl-none shadow-lg border-2 border-white animate-[bounce_3s_infinite] z-20">
                <div className="flex gap-1 items-baseline">
                    <span className="font-bold text-xl">あ</span>
                    <span className="font-bold text-sm opacity-90">é</span>
                </div>
                <div className="w-2 h-2 bg-sky-500 absolute -bottom-1 -left-1 rotate-45"></div>
            </div>
            <div className="absolute -left-12 top-10 bg-orange-500 text-white w-14 h-14 flex items-center justify-center rounded-2xl rounded-tr-none shadow-lg border-2 border-white animate-[bounce_3.5s_infinite] z-20 delay-75">
                <span className="font-bold text-2xl">A</span>
                <div className="w-2 h-2 bg-orange-500 absolute -top-0.5 -right-1 rotate-45"></div>
            </div>
        </div>

        {/* Shadow */}
        <div className={`absolute -bottom-6 left-1/2 -translate-x-1/2 w-32 h-4 bg-black/10 rounded-[100%] blur-sm -z-10 transition-opacity duration-300 ${isZooming ? 'opacity-0' : 'opacity-100'}`}></div>
      </div>

      <div className={`transition-all duration-500 ${isZooming ? 'opacity-0 translate-y-10' : 'opacity-100'}`}>
        <h1 className="text-4xl md:text-6xl font-black text-gray-800 tracking-tighter drop-shadow-sm mb-1">
            <span className="text-orange-500">DUBBY</span>
        </h1>
        
        <p className="text-sm md:text-lg text-gray-400 font-medium max-w-lg mx-auto leading-relaxed px-4">
            Speaking everyone's language, <span className="text-orange-500 font-bold">right on time.</span>
        </p>
      </div>

    </header>
  );
};

export default Header;