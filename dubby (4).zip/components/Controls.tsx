import React from 'react';
import { AppState, Language, GeminiVoice } from '../types';
import { Sparkles, Loader2, Globe, ChevronDown, Mic } from 'lucide-react';

interface ControlsProps {
  appState: AppState;
  targetLanguage: Language;
  setTargetLanguage: (lang: Language) => void;
  voice: GeminiVoice;
  setVoice: (voice: GeminiVoice) => void;
  onDub: () => void;
  hasFile: boolean;
}

const Controls: React.FC<ControlsProps> = ({
  appState,
  targetLanguage,
  setTargetLanguage,
  voice,
  setVoice,
  onDub,
  hasFile
}) => {
  const isProcessing = appState === AppState.PROCESSING_WATCHING || appState === AppState.PROCESSING_REWRITING;
  const isComplete = appState === AppState.COMPLETE;

  return (
    <div className="w-full max-w-3xl mx-auto flex flex-col md:flex-row items-stretch gap-2 md:gap-3 justify-between bg-white p-2 md:p-3 rounded-[1.5rem] md:rounded-[2rem] shadow-xl shadow-sky-100/50 border border-sky-50">
      
      {/* Language Selector */}
      <div className="relative flex-1 group">
        <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none z-10">
           <Globe className="w-4 h-4 md:w-5 md:h-5 text-sky-500 group-focus-within:text-sky-600 transition-colors" />
        </div>
        <select
          id="language-select"
          value={targetLanguage}
          onChange={(e) => setTargetLanguage(e.target.value as Language)}
          disabled={isProcessing}
          className="w-full h-full appearance-none bg-sky-50/50 hover:bg-sky-50 border-2 border-transparent hover:border-sky-100 text-sky-900 text-sm md:text-lg font-bold py-2 md:py-3 pl-10 md:pl-12 pr-8 md:pr-10 rounded-[1.2rem] md:rounded-[1.5rem] focus:outline-none focus:ring-4 focus:ring-sky-100 focus:border-sky-200 cursor-pointer transition-all"
        >
          {Object.values(Language).map((lang) => (
            <option key={lang} value={lang}>{lang}</option>
          ))}
        </select>
        <div className="pointer-events-none absolute inset-y-0 right-4 flex items-center text-sky-400">
          <ChevronDown className="w-4 h-4" />
        </div>
      </div>

      {/* Voice Selector */}
      <div className="relative flex-1 group">
        <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none z-10">
           <Mic className="w-4 h-4 md:w-5 md:h-5 text-sky-500 group-focus-within:text-sky-600 transition-colors" />
        </div>
        <select
          id="voice-select"
          value={voice}
          onChange={(e) => setVoice(e.target.value as GeminiVoice)}
          disabled={isProcessing}
          className="w-full h-full appearance-none bg-sky-50/50 hover:bg-sky-50 border-2 border-transparent hover:border-sky-100 text-sky-900 text-sm md:text-lg font-bold py-2 md:py-3 pl-10 md:pl-12 pr-8 md:pr-10 rounded-[1.2rem] md:rounded-[1.5rem] focus:outline-none focus:ring-4 focus:ring-sky-100 focus:border-sky-200 cursor-pointer transition-all"
        >
          {Object.values(GeminiVoice).map((v) => (
            <option key={v} value={v}>{v} Voice</option>
          ))}
        </select>
        <div className="pointer-events-none absolute inset-y-0 right-4 flex items-center text-sky-400">
          <ChevronDown className="w-4 h-4" />
        </div>
      </div>

      {/* Action Button */}
      <button
        onClick={onDub}
        disabled={!hasFile || isProcessing}
        className={`
          relative flex-1 md:flex-none md:min-w-[180px] flex items-center justify-center gap-2 
          py-2 md:py-3 px-6 md:px-8 rounded-[1.2rem] md:rounded-[1.5rem] text-base md:text-xl font-black text-white shadow-lg transition-all
          ${!hasFile || isProcessing 
            ? 'bg-gray-200 text-gray-400 shadow-none cursor-not-allowed' 
            : 'bg-gradient-to-r from-orange-500 to-orange-400 hover:to-orange-500 hover:scale-[1.02] hover:shadow-orange-500/30 active:scale-95'
          }
        `}
      >
        {isProcessing ? (
          <>
            <Loader2 className="w-4 h-4 md:w-5 md:h-5 animate-spin" />
            <span className="font-bold">Working...</span>
          </>
        ) : (
          <>
            <span className="tracking-wide">{isComplete ? 'Dub Again!' : 'DUB IT!'}</span>
            {!isProcessing && <Sparkles className="w-4 h-4 md:w-5 md:h-5 fill-white/20 animate-pulse" />}
          </>
        )}
      </button>
    </div>
  );
};

export default Controls;